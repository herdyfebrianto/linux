#define LINUX_PACKAGE_ID " Debian 5.7.17-1kali1"

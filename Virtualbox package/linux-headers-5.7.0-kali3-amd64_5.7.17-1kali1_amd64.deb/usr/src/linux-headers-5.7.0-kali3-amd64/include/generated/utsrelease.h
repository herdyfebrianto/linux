#define UTS_RELEASE "5.7.0-kali3-amd64"
